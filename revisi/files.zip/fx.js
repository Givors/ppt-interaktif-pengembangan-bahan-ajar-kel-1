/* fx.js — lapisan efek. Dimuat SETELAH main.js. Jika salah satu library gagal dimuat,
   situs tetap jalan seperti versi sebelumnya (progressive enhancement). */
(() => {
if (!(window.THREE && window.gsap && window.anime && window.Motion)) return;
const { animate, stagger } = Motion, R = Math.random, TAU = Math.PI * 2;
const RM = matchMedia('(prefers-reduced-motion: reduce)').matches, D = x => RM ? 0 : x;
const cv = document.getElementById('fx'); let renderer;
try { renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true }); } catch (e) { return; }
document.documentElement.classList.add('fx');

/* ===== THREE.js: awan partikel + GSAP untuk morph / burst ===== */
const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(50, 1, .1, 50); cam.position.z = 6;
const N = innerWidth < 700 ? 1600 : 2800;
const S = {
  sphere: () => { const u = R() * TAU, v = Math.acos(2 * R() - 1); return [Math.sin(v) * Math.cos(u), Math.sin(v) * Math.sin(u), Math.cos(v)]; },
  disc: () => { const a = R() * TAU, edge = R() < .25, r = edge ? 1 : Math.sqrt(R()); return [Math.cos(a) * r, Math.sin(a) * r, (edge ? R() - .5 : R() < .5 ? .5 : -.5) * .28]; },
  torus: () => { const u = R() * TAU, v = R() * TAU, k = 1 + .4 * Math.cos(v); return [k * Math.cos(u) * .8, k * Math.sin(u) * .8, .32 * Math.sin(v)]; },
  cube: () => { const p = [R() * 2 - 1, R() * 2 - 1, R() * 2 - 1]; p[R() * 3 | 0] = R() < .5 ? -1 : 1; return p.map(x => x * .85); },
  helix: () => { const t = R() * TAU * 2.5, s = R() < .5 ? 0 : Math.PI; return [Math.cos(t + s) * .7, (t / (TAU * 2.5) - .5) * 2.2, Math.sin(t + s) * .7]; },
  twin: () => { const s = R() < .5 ? -1 : 1, p = S.sphere(); return [p[0] * .5 + s * .75, p[1] * .5, p[2] * .5]; },
  cone: () => { const h = R(), a = R() * TAU, r = (1 - h) * .9; return [Math.cos(a) * r, h * 1.6 - .8, Math.sin(a) * r]; },
  spiky: () => { const k = R() < .35 ? 1.7 : .9; return S.sphere().map(x => x * k); },
  stack: () => { const k = R() * 4 | 0, p = S.disc(); return [p[0] * .8, k * .5 - .75 + p[2] * .4, p[1] * .8]; }
};
const NAMES = ['disc', 'torus', 'sphere', 'cube', 'helix', 'twin', 'cone', 'spiky', 'stack', 'disc'];
const TILE = { seller: 'sphere', goods: 'cube', payment_tool: 'disc', buyer: 'twin' };
const cache = {}, shape = n => cache[n] || (cache[n] = (() => {
  const a = new Float32Array(N * 3); for (let i = 0; i < N; i++) a.set(S[n](), i * 3); return a; })());
const pos = new Float32Array(N * 3), base = new Float32Array(N * 3), from = new Float32Array(N * 3), to = new Float32Array(N * 3);
const dir = Float32Array.from({ length: N * 3 }, () => R() * 2 - 1), dl = Float32Array.from({ length: N }, R);
const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
const tc = document.createElement('canvas'); tc.width = tc.height = 64; const cx = tc.getContext('2d'), gr = cx.createRadialGradient(32, 32, 0, 32, 32, 32);
gr.addColorStop(0, '#fff'); gr.addColorStop(.45, '#fffc'); gr.addColorStop(1, '#fff0'); cx.fillStyle = gr; cx.fillRect(0, 0, 64, 64);
const mat = new THREE.PointsMaterial({ size: .05, map: new THREE.CanvasTexture(tc), transparent: true, depthWrite: false, opacity: .95, color: 0xbe185d });
const pts = new THREE.Points(geo, mat), grp = new THREE.Group(); grp.add(pts); scene.add(grp);
const st = { t: 1, burst: 0 };

function morph(n) {
  from.set(base); to.set(shape(n)); st.t = 0;
  gsap.to(st, { t: 1, duration: D(1.8), ease: 'power3.inOut', overwrite: 'auto' });
}
function burst(a = 1) { if (!RM) gsap.fromTo(st, { burst: 0 }, { burst: a, duration: .3, ease: 'power2.out', yoyo: true, repeat: 1, overwrite: 'auto' }); }
let pt; function pulse(n) { morph(n); clearTimeout(pt); pt = setTimeout(() => morph(NAMES[currentSlide]), 1600); }
function recolor() { const c = new THREE.Color(getComputedStyle(document.body).getPropertyValue('--ac').trim() || '#be185d'); gsap.to(mat.color, { r: c.r, g: c.g, b: c.b, duration: D(.6) }); }
function place(i, d = 1.2) {
  const W = innerWidth, H = innerHeight, vh = 5.6, vw = vh * W / H, h = document.querySelector('.hero'); let px, py, sz;
  if (i === 0 && h && h.offsetWidth) { const r = h.getBoundingClientRect(); px = r.left + r.width / 2; py = r.top + r.height / 2; sz = r.width * 1.1; }
  else if (W > 1150) { const g = (W - 1000) / 2; px = i % 2 ? W - g / 2 : g / 2; py = H * .5; sz = Math.min(g * .7, 240); }
  else { px = i % 2 ? W * .9 : W * .1; py = H * .1; sz = 70; }
  const s = sz / H * vh / 2, o = { duration: D(d), ease: 'power3.inOut' };
  gsap.to(grp.position, { x: (px / W - .5) * vw, y: -(py / H - .5) * vh, ...o });
  gsap.to(grp.scale, { x: s, y: s, z: s, ...o }); gsap.to(mat, { size: .05 * Math.max(.55, s), ...o });
}
const qx = gsap.quickTo(grp.rotation, 'x', { duration: .9 }), qy = gsap.quickTo(grp.rotation, 'y', { duration: .9 });
addEventListener('pointermove', e => { qx((e.clientY / innerHeight - .5) * .7); qy((e.clientX / innerWidth - .5) * 1); });
addEventListener('pointerdown', e => { if (!e.target.closest('button,a,summary,iframe')) burst(.9); });
function size() { renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.setSize(innerWidth, innerHeight, false); cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix(); }
addEventListener('resize', () => { size(); place(currentSlide, 0); });
function frame(ms) {
  for (let i = 0, t = ms * .001; i < N; i++) {
    const k0 = Math.min(1, Math.max(0, st.t * 1.4 - dl[i] * .4)), k = k0 * k0 * (3 - 2 * k0);
    for (let a = 0, j = i * 3; a < 3; a++, j++) { const b = from[j] + (to[j] - from[j]) * k; base[j] = b; pos[j] = b + dir[j] * st.burst * 1.6 + (RM ? 0 : Math.sin(t * 1.4 + i) * .01); }
  }
  geo.attributes.position.needsUpdate = true; if (!RM) pts.rotation.y += .005;
  renderer.render(scene, cam); requestAnimationFrame(frame);
}

/* ===== motion (mesin Framer Motion): transisi slide + spring tombol ===== */
function enter(i) {
  const s = slides[i], kids = [...s.querySelectorAll(':scope > *:not(.coins)')];
  if (RM) return;
  animate(s, { opacity: [0, 1], y: [48, 0], scale: [.95, 1] }, { type: 'spring', stiffness: 170, damping: 20 });
  animate(kids, { opacity: [0, 1], y: [26, 0] }, { type: 'spring', stiffness: 240, damping: 22, delay: stagger(.07, { startDelay: .12 }) });
  if (i === 0) setTimeout(() => place(0, .6), 900);
  if (i === 4) setTimeout(flow, 900);
}
const PR = '.btn,.opt,.item,.tile,.bill,.dots button,.sw', SP = { type: 'spring', stiffness: 420, damping: 18 };
document.addEventListener('pointerdown', e => { const el = e.target.closest(PR); if (el && !el.disabled && !RM) animate(el, { scale: .93 }, SP); });
document.addEventListener('pointerup', e => { const el = e.target.closest(PR); if (el && !RM) animate(el, { scale: 1 }, SP); });
document.addEventListener('pointerover', e => { const el = e.target.closest(PR); if (e.pointerType === 'mouse' && el && !el.disabled && !RM && !el.contains(e.relatedTarget)) animate(el, { scale: 1.05 }, SP); });
document.addEventListener('pointerout', e => { const el = e.target.closest(PR); if (el && !RM && !el.contains(e.relatedTarget)) animate(el, el.matches('.tile') ? { scale: 1, rotateX: 0, rotateY: 0 } : { scale: 1 }, SP); });
document.addEventListener('pointermove', e => {
  const t = e.pointerType === 'mouse' && e.target.closest?.('.tile'); if (!t || RM) return; const r = t.getBoundingClientRect();
  animate(t, { rotateX: -((e.clientY - r.top) / r.height - .5) * 18, rotateY: ((e.clientX - r.left) / r.width - .5) * 18 }, { duration: .2 });
});

/* ===== anime.js: koin melompat di alur, hitung harga, kuis ===== */
function lit(li) { li.classList.add('lit'); if (!RM) animate(li, { scale: [1, 1.12, 1] }, { duration: .45 }); }
function flow() {
  const ol = document.querySelector('.steps'); if (!ol) return; let h = ol.querySelector('.hop');
  if (!h) { h = document.createElement('span'); h.className = 'hop'; h.textContent = '🪙'; h.setAttribute('aria-hidden', 'true'); ol.appendChild(h); }
  const lis = [...ol.querySelectorAll('li')], at = li => ({ left: li.offsetLeft + li.offsetWidth / 2 - 16, top: li.offsetTop - 18 });
  lis.forEach(l => l.classList.remove('lit')); anime.remove(h);
  const tl = anime.timeline({ easing: 'easeInOutCubic' });
  lis.forEach((li, k) => tl.add({ targets: h, ...at(li), duration: k ? 650 : 1, complete: () => lit(li) }));
  ol.onclick = e => { const li = e.target.closest('li'); if (!li) return; anime.remove(h); anime({ targets: h, ...at(li), duration: 500, easing: 'easeOutBack', complete: () => lit(li) }); buzz(25); };
}

/* ===== sambungkan ke fungsi di main.js ===== */
const _go = window.go; window.go = i => { _go(i); const n = currentSlide; morph(NAMES[n]); place(n); enter(n); };
const _theme = window.setTheme; window.setTheme = c => { _theme(c); recolor(); };
const _pop = window.openPopupKey; window.openPopupKey = k => { _pop(k); pulse(TILE[k]); burst(.5); };
const _chk = window.checkQuiz; window.checkQuiz = (i, c, b) => {
  const live = !locked && !b.disabled; _chk(i, c, b);
  if (live && i === c) { burst(1.3); pulse('spiky'); }
};
const _lq = window.loadQuiz; window.loadQuiz = () => { _lq(); if (!RM && document.querySelector('#quiz-options .opt')) anime({ targets: '#quiz-options .opt', opacity: [0, 1], translateY: [30, 0], delay: anime.stagger(90), easing: 'easeOutBack', duration: 600 }); };
const _pp = window.proceedToPay; window.proceedToPay = () => {
  _pp(); if (selectedItemIndex === null) return;
  const o = { v: 0 }, el = $('target-price'); anime({ targets: o, v: items[selectedItemIndex].price, round: 1, duration: D(900), easing: 'easeOutExpo', update: () => { el.textContent = money(o.v); } });
};
const _pay = window.pay; window.pay = v => {
  const was = $('payment-panel').classList.contains('ok'); _pay(v);
  if (!was && $('payment-panel').classList.contains('ok')) { burst(1.5); pulse('spiky'); }
};

/* ===== uang: seret dengan pointer (jalan di layar sentuh), ketuk tetap bisa ===== */
let moved = false;
const hit = (r, e, p = 24) => e.clientX > r.left - p && e.clientX < r.right + p && e.clientY > r.top - p && e.clientY < r.bottom + p;
function startDrag(e, b) {
  if (b.disabled) return; moved = false; const x0 = e.clientX, y0 = e.clientY, z = $('drop-zone'); let g;
  const mv = ev => {
    const dx = ev.clientX - x0, dy = ev.clientY - y0;
    if (!g && Math.hypot(dx, dy) > 8) {
      moved = true; g = b.cloneNode(true); g.classList.add('ghost'); g.removeAttribute('id'); const r = b.getBoundingClientRect();
      Object.assign(g.style, { position: 'fixed', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', zIndex: 90, pointerEvents: 'none' });
      document.body.appendChild(g); b.style.opacity = .3;
    }
    if (g) { gsap.set(g, { x: dx, y: dy, rotation: dx * .05, scale: 1.1 }); z.classList.toggle('over', hit(z.getBoundingClientRect(), ev)); }
  };
  const up = ev => {
    removeEventListener('pointermove', mv); removeEventListener('pointerup', up); removeEventListener('pointercancel', up);
    if (!g) return; z.classList.remove('over'); b.style.opacity = '';
    if (ev.type === 'pointerup' && hit(z.getBoundingClientRect(), ev)) { g.remove(); pay(+b.dataset.value); }
    else gsap.to(g, { x: 0, y: 0, rotation: 0, scale: 1, duration: .45, ease: 'back.out(1.8)', onComplete: () => g.remove() });
    setTimeout(() => { moved = false; }, 0);
  };
  addEventListener('pointermove', mv); addEventListener('pointerup', up); addEventListener('pointercancel', up);
}
const _rw = window.renderWallet; window.renderWallet = () => {
  _rw(); document.querySelectorAll('.bill').forEach(b => {
    b.draggable = false; b.onclick = null; b.ondragstart = null;
    b.addEventListener('pointerdown', e => startDrag(e, b)); b.addEventListener('click', () => { if (!moved) pay(+b.dataset.value); });
  });
};

/* ===== mulai ===== */
function boot() {
  size(); recolor();
  for (let i = 0; i < N * 3; i++) from[i] = (R() * 2 - 1) * 3.2;
  base.set(from); to.set(shape('disc')); st.t = 0; place(0, 0);
  gsap.to(st, { t: 1, duration: D(2.4), delay: .2, ease: 'power3.out' });
  enter(0); requestAnimationFrame(frame);
}
document.readyState === 'complete' ? boot() : addEventListener('load', boot);
})();
